
mTCP Source Code Readme
2020-03-07 Version

Home page: http://www.brutman.com/mTCP


Welcome to the mTCP source code!

mTCP documentation has moved to the developers.pdf file.  Topics include
the directory structure, what compiler to use, architecture and design
notes, and miscellaneous notes for programming under DOS.

Note: HTTPServ source code is not provided at this time.  It's overly
complex and I am not terribly proud of it.  Look for a smaller,
slimmer version in the future.



Enjoy!

Mike
mbbrutman@gmail.com

